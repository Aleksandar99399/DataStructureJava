package interfaces;

public interface Solvable {
    Boolean solve();
}
